from django.db import models

# Create your models here.
class Item(models.Model):
    productName = models.CharField(max_length=255)
    price = models.CharField(max_length=2)
    category = models.CharField(max_length=255)

    def __str__(self) -> str:
        return self.name