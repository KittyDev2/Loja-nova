from django.apps import AppConfig


class MinhaLojaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "minha_loja"
